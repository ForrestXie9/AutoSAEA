function  [obj, fit] = objfunc(theta, par)
n=size(par.D,2);
% theta=theta*ones(n,1);
% Initialize
obj = inf; 
fit = struct('sigma2',NaN, 'beta',NaN, 'gamma',NaN, ...
    'C',NaN, 'Ft',NaN, 'G',NaN);
m = size(par.F,1);
% Set up  R
r = feval(par.corr, theta, par.D);
idx = find(r > 0);  
o = (1 : m)';   
mu = 0.5*(10+m)*eps;
R = sparse([par.ij(idx,1); o], [par.ij(idx,2); o],[r(idx); 0.5*ones(m,1)+mu]);
R=R+R';
% Cholesky factorization with check for pos. def.
[C rd] = chol(R);
if  rd  
    return
end % not positive definite
% Get least squares solution
C = C'; 
Ft = C \ par.F;
[Q G] = qr(Ft,0);
if  rcond(G) < 1e-60
  % Check   F  
  if  cond(par.F) > 1e100
    T = sprintf('F is too ill conditioned\nPoor combination of regression model and design sites');
    error(T)
  else  % Matrix  Ft  is too ill conditioned
    return 
  end 
end
Yt = C \ par.y; 
beta = G \ (Q'*Yt);
rho = Yt - Ft*beta; 
sigma2 = sum(rho.^2)/m;
detR = det(R) .^ (1/m) ;
obj = sum(sigma2) * detR;
if  nargout > 1
  fit = struct('sigma2',sigma2, 'beta',beta, 'gamma',rho' / C, ...
    'C',C, 'Ft',Ft, 'G',G');
end
end

