function  [Fsi]=findtheta(theta)
global ppar
Fsi=objfunc(theta,ppar);
end
